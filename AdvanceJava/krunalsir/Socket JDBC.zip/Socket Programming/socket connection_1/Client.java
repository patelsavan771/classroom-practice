
import java.net.*;
import java.io.*;

 class Client
{
	public static void main(String args[])throws Exception
	{
	Socket s = new Socket("localhost",1235);
	}
}

