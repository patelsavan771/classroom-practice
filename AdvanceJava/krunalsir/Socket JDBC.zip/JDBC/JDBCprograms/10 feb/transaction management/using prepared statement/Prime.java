class Prime
{
	public static void main(String args[])
	{
		int a=10,b=50,i,j;
		for(i=a;i<=b;i++)
		{
			int count=0;
			for(j=1;j<=i;j++)
			{
				if(j%i==0)
				{
				  count++;
				}
				if(count==2)
				{
					System.out.println("\n"+j);                                                                                                                                                                                    )
				}
				
			
			}
		}
	}
}